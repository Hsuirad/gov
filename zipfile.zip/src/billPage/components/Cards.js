import React, {Component} from 'react';
import BillPres from './BillPres'
import data from '../../scripts/data.json'
import Spinner from 'react-bootstrap/Spinner'

    /*
    "0":{"title":
    "names":"\n\tTo amend the Alaska Native Claims Settlement Act to exclude certain payments to Alaska Native elders for determining eligibility for certain programs, and for other purposes.",
    "sponsors":"\n\tSponsor: Rep. Young, Don [R-AK-At Large] (Introduced 10/23/2020) Cosponsors: (0)",
    "bills":"\n\tTo amend the Alaska Native Claims Settlement Act to exclude certain payments to Alaska Native elders for determining eligibility for certain programs, and for other purposes.",
    "latestAction":"\n\t2020-10-23 - Introduced in House",
    "coms":"\n\tCommittees: House - Natural Resources",
    "tracker":"\n\tIntroduced House"}
    */
 
export default class Cards extends Component{
    findPos = () => {
        if((window.pageYOffset + window.innerHeight >= document.body.offsetHeight-document.body.offsetHeight*0.01) && (this.state.showLoading === false)){

            this.state.showLoading = true
            this.setState({showLoading: true})
            console.log('test' + this.state.showLoading)

            setTimeout((()=>{

                let b = this.state.bills;

                this.state.showLoading = false;
                this.setState({showLoading: false})
                
                console.log(this.state.indicesNow)

                let ind  = [...this.state.indicesNow]

                console.log(ind.toString(), this.state.indicesNow)

                let start = ind[ind.length - 1] + 1;
                let end = ind[ind.length - 1] + 10

                console.log(start, end)

                for(let i = start; i <= end; i++){
                    ind.push(i);
                    if(this.state.data.hasOwnProperty(i.toString()))
                        b.push({
                            index: i,
                            link: 'https://www.com.com', 
                            isPinned: false,
                            title: this.state.data[i]['title'], 
                            auth: this.state.data[i]['sponsors'],
                            authLink: 'https://stewart.house.gov/issues/',
                            sum: this.state.data[i]['bills']
                        })
                    //console.log(this.state.data, b, this.state.showLoading, ind);
                }

                console.log(b);
                
                this.setState({
                    bills: [...b],
                    showLoading: false,
                    indicesNow: [...ind]
                })

            }), 1000)

            //console.log('bottom')

        }
    }
    constructor(props){
        super()
        this.state = {
            showLoading: false,
            bills: [],
            size: props.size,
            width: props.width,
            indicesNow: [],
            colorMode: props.color,
            givenData: (props.data.length>0?true:false),
            data: (props.data.length>0?props.data:data),
            pinnedCards: []
        }

        let ind = []


        if(!this.state.givenData){
            for(let i = 0; i < 10; i++){
                this.state.indicesNow.push(i);
                this.state.bills.push({
                    index: i,
                    link: 'https://www.com.com', 
                    isPinned: false,
                    title: this.state.data[i]['title'], 
                    auth: this.state.data[i]['sponsors'],
                    authLink: 'https://stewart.house.gov/issues/',
                    sum: this.state.data[i]['bills']
                })
            }
        }
        else{
            console.log("test")
            let i = 0;  
            this.state.data = [...localStorage.getItem('data').split(',')]
            console.log(this.state.data)

            this.state.data.forEach(elem => {
                console.log(elem)
                this.state.indicesNow.push(i);
                this.state.bills.push({
                    index: Object.keys(this.state.data)[i],
                    link: 'https://www.com.com', 
                    isPinned: true,
                    title: data[elem]['title'], 
                    auth: data[elem]['sponsors'],
                    authLink: 'https://stewart.house.gov/issues/',
                    sum: data[elem]['bills']
                })
                i++
            })
        }

        //this.setState({indicesNow: [...ind]})
        console.log(this.state.indicesNow)

        //setInterval(this.findPos, 10)
    }

    update = () => {
        this.setState({size: this.props.size, width: this.props.width});
    }

    componentDidMount(){
        console.log('test')
        if(!this.state.givenData)window.addEventListener('scroll', this.findPos)
    }

    componentWillUnmount(){
        if(!this.state.givenData)window.removeEventListener('scroll', this.findPos)
    }

    componentDidUpdate(previousProps, previousState) {
        if (previousProps.color !== this.props.color) {
            this.setState({colorMode: this.props.color})
        }
    }

    pushPins = (e) => {
        console.log(e)
        this.props.updatePins(e)
        this.state.pinnedCards.push(e)
    }
    
    
    render(){
        return(
            <div style={{paddingTop: '60px'}}>{console.log((this.state.showLoading)&&(this.state.givenData==false)?"visible":"hidden")}
                {this.state.bills.map(bill => <BillPres authLink = {bill.authLink} isPinned = {bill.isPinned} index = {bill.index} updatePins = {this.pushPins} link={bill.link} width={this.state.width} margins = {this.state.size} isDem = {bill.auth.includes("[D-")?true:false} title = {bill.title} color = {this.state.colorMode} auth={bill.auth} sum={bill.sum} />)}
                <Spinner style={{marginBottom: "14%", filter: this.state.colorMode=="light"?'':'invert(1)', visibility: (this.state.showLoading)&&(this.state.givenData==false)?"visible":"hidden"}} animation="border" role="status" visibility = {(this.state.showLoading)&&(this.state.givenData==false)?"visible":"hidden"}></Spinner>
            </div>
        )
    }
}
