import React, {Component} from 'react';
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'
import '../../index.css'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import FormControl from 'react-bootstrap/FormControl'
import logo from '../../cursivelogo.png'
import { Link, BrowserRouter as Router } from 'react-router-dom'

export default class BottomBar extends Component{
    constructor(){
        super();
        this.state = {
            color: 'light',
            toggleClass: '.toggle',
            content: '☀️',
            pinnedCards: []
        }
    }

    flipState = () => {
        if(this.state.color == 'light'){
            this.setState({
                color: 'dark'
            });
            this.props.handleChange('dark')
        } else{
            this.setState({
                color: 'light'
            })
            this.props.handleChange('light')
        }
    }

    // document.querySelector('.toggle').addEventListener('click', function() {
    //     this.classList.add('animate');

    //     console.log('test')
        
    //     setTimeout(() => {
    //         this.classList.toggle('active');
    //     }, 150);
        
    //     setTimeout(() => this.classList.remove('animate'), 300);
    // });

    // changeClass = () => {
    //     if(this.state.content == "🌒"){
    //         this.setState({toggleClass: '.toggle animate', content: '☀️'});

    //         setTimeout(() => {
    //             this.setState({toggleClass: '.toggle animate active', content: '☀️'})
    //         }, 150)

    //         setTimeout(() => this.setState({toggleClass: '.toggle active', content: '☀️'}), 300)
    //     } else{
    //         this.setState({toggleClass: '.toggle animate', content: '🌒'});

    //         setTimeout(() => {
    //             this.setState({toggleClass: '.toggle animate active', content: '🌒'})
    //         }, 150)

    //         setTimeout(() => this.setState({toggleClass: '.toggle active', content: '🌒'}), 300)
    //     }
    // }

    // // .toggle {
    //     position: absolute;
    //     cursor: pointer;
    //     top: 20px;
    //     right: 25px;
    //     font-size: 150%;
    //   }
      
    //   .toggle {
    //     content: '☀️';
    //   }
      
    //   .toggle.active {
    //     content: '🌒';
    //   }
      
    //   .toggle.animate {
    //     animation: animate .3s cubic-bezier(0.4, 0.0, 0.2, 1);
    //   }
      
    //   @keyframes animate {
    //     0%   { transform: scale(1); }
    //     50%  { transform: scale(0); }
    //     100% { transform: scale(1); }
    //   }

    componentDidUpdate(previousProps, previousState) {
        console.log(this.props.pinnedCards)
        if (previousProps.pinnedCards !== this.props.pinnedCards) {
            this.setState({pinnedCards: this.props.pinnedCards})
        }
    }

    refresh = () => {
        console.log(this.props.pinnedCards)
        localStorage.setItem('data', this.props.pinnedCards)
        console.log(localStorage)
        setTimeout(()=>window.location.reload(), 100)
    }

    render(){
        return(
            <div>
                <Navbar style = {{justifyContent: 'center'}} bg = {this.state.color} variant = {this.state.color} fixed = 'top'>
                    <Navbar.Brand> {/*204 height 808 width*/}
                        <img style = {{filter: this.state.color=='dark'?'invert(1)':''}} src={logo} height={204/8} width = {808/8} alt=""></img>
                    </Navbar.Brand>
                </Navbar>
                <Navbar bg={this.state.color} variant = {this.state.color} fixed = 'bottom' expand="lg">
                    
                        <Link to = '/'><Nav.Link onClick = {this.refresh} style={{color:this.state.color=='dark'?'white':'black'}} href="#home"><i class="fas fa-home fa-lg"></i></Nav.Link></Link>
                       <Link to = '/pinned'><Nav.Link onClick = {this.refresh} style={{color:this.state.color=='dark'?'white':'black'}} href="#bink"><i class="fas fa-thumbtack fa-lg"></i></Nav.Link></Link>
                       <Link to = '/bills'><Nav.Link onClick = {this.refresh} style={{color:this.state.color=='dark'?'white':'black'}} href="#link"><i class="fas fa-newspaper fa-lg"></i></Nav.Link></Link>
                        <Link to = '/congressmembers'><Nav.Link onClick = {this.refresh} style={{color:this.state.color=='dark'?'white':'black'}} href="#tink"><i class="fas fa-search fa-lg"></i></Nav.Link></Link> {/*Have a profile site for all the representatives and senators*/} 
                        <Nav.Link onClick = {() => {this.flipState()}} style={{color:this.state.color=='dark'?'white':'black'}} href="#jink">
                            <span style = {{
                                cursor: 'pointer',
                                color: this.state.color=='dark'?'white':'black'
                            }}><i class={`${this.state.color=='dark'?'far':'fas'} fa-lightbulb fa-lg`}></i></span>
                        </Nav.Link>
                        {/* <Nav.Link onClick = {() => this.flipState()}>Toggle  mode</Nav.Link> */}
                        
                            
                       {/* <Form inline>
                            { ADD THIS LATER IN SOME OTHER SECTION <FormControl type="text" placeholder="Search Bills" className="mr-sm-2" />
                            <Button variant="outline-success">Search</Button> }
                            <span onClick = {() => {this.flipState()}} style = {{
                                cursor: 'pointer',
                                color: this.state.color=='dark'?'white':'black'
                            }}><i class={`${this.state.color=='dark'?'far':'fas'} fa-lightbulb fa-lg`}></i></span>
                        </Form>*/}
                </Navbar>
            </div>

            // <div class="card promoting-card">

            //     {/* <!-- Card content --> */}
            //     <div class="card-body d-flex flex-row">

            //         {/* <!-- Avatar --> */}
            //         <img src="https://mdbootstrap.com/img/Photos/Avatars/avatar-8.jpg" class="rounded-circle mr-3" height="50px" width="50px" alt="avatar">

            //         {/* <!-- Content --> */}
            //         <div>

            //         {/* <!-- Title --> */}
            //         <h4 class="card-title font-weight-bold mb-2">New spicy meals</h4>
            //         {/* <!-- Subtitle --> */}
            //         <p class="card-text"><i class="far fa-clock pr-2"></i>07/24/2018</p>

            //         </div>

            //     </div>

            //     {/* <!-- Card image --> */}
            //     <div class="view overlay">
            //         <img class="card-img-top rounded-0" src="https://mdbootstrap.com/img/Photos/Horizontal/Food/full page/2.jpg" alt="Card image cap">
            //         <a href="#!">
            //         <div class="mask rgba-white-slight"></div>
            //         </a>
            //     </div>

            //     {/* <!-- Card content --> */}
            //     <div class="card-body">

            //         <div class="collapse-content">

            //         {/* <!-- Text --> */}
            //         <p class="card-text collapse" id="collapseContent">Recently, we added several exotic new dishes to our restaurant menu. They come from countries such as Mexico, Argentina, and Spain. Come to us, have some delicious wine and enjoy our juicy meals from around the world.</p>
            //         {/* <!-- Button --> */}
            //         <a class="btn btn-flat red-text p-1 my-1 mr-0 mml-1 collapsed" data-toggle="collapse" href="#collapseContent" aria-expanded="false" aria-controls="collapseContent"></a>
            //         <i class="fas fa-share-alt text-muted float-right p-1 my-1" data-toggle="tooltip" data-placement="top" title="Share this post"></i>
            //         <i class="fas fa-heart text-muted float-right p-1 my-1 mr-3" data-toggle="tooltip" data-placement="top" title="I like it"></i>

            //         </div>

            //     </div>

            // </div>
        )
    }
}